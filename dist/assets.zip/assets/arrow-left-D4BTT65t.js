import{c as o}from"./index-Clcy_W23.js";const e=[["path",{d:"m12 19-7-7 7-7",key:"1l729n"}],["path",{d:"M19 12H5",key:"x3x0zl"}]],r=o("ArrowLeft",e);export{r as A};
